#
# TABLE STRUCTURE FOR: t_gudang
#

DROP TABLE IF EXISTS `t_gudang`;

CREATE TABLE `t_gudang` (
  `id_bahan_kimia` int(11) NOT NULL AUTO_INCREMENT,
  `nama_bahan` text NOT NULL,
  `nama_kimia` text NOT NULL,
  `katalog` text NOT NULL,
  `jumlah` text NOT NULL,
  `file_bahan_kimia` text NOT NULL,
  PRIMARY KEY (`id_bahan_kimia`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_instruksi_kerja
#

DROP TABLE IF EXISTS `t_instruksi_kerja`;

CREATE TABLE `t_instruksi_kerja` (
  `id_instruksi_kerja` int(11) NOT NULL AUTO_INCREMENT,
  `nama_instruksi_kerja` text NOT NULL,
  `file_instruksi_kerja` text NOT NULL,
  PRIMARY KEY (`id_instruksi_kerja`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_jenis_uji
#

DROP TABLE IF EXISTS `t_jenis_uji`;

CREATE TABLE `t_jenis_uji` (
  `id_jenis_uji` int(11) NOT NULL AUTO_INCREMENT,
  `id_kelompok_jenis_uji` int(11) NOT NULL,
  `nama_lengkap` text NOT NULL,
  `nama_singkat` text NOT NULL,
  `rumus` text NOT NULL,
  `hasil` text NOT NULL,
  `satuan` text NOT NULL,
  `ref_method` text NOT NULL,
  PRIMARY KEY (`id_jenis_uji`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_kelompok_jenis_uji
#

DROP TABLE IF EXISTS `t_kelompok_jenis_uji`;

CREATE TABLE `t_kelompok_jenis_uji` (
  `id_kelompok_jenis_uji` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kelompok_jenis_uji` text NOT NULL,
  PRIMARY KEY (`id_kelompok_jenis_uji`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_klien
#

DROP TABLE IF EXISTS `t_klien`;

CREATE TABLE `t_klien` (
  `id_klien` int(11) NOT NULL AUTO_INCREMENT,
  `nama_klien` text NOT NULL,
  `kontak_klien` text NOT NULL,
  `telepon_klien` text NOT NULL,
  `alamat_klien` text NOT NULL,
  PRIMARY KEY (`id_klien`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_level_user
#

DROP TABLE IF EXISTS `t_level_user`;

CREATE TABLE `t_level_user` (
  `id_level_user` int(11) NOT NULL AUTO_INCREMENT,
  `nama_level_user` varchar(255) NOT NULL,
  PRIMARY KEY (`id_level_user`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `t_level_user` (`id_level_user`, `nama_level_user`) VALUES (1, 'Administrator');
INSERT INTO `t_level_user` (`id_level_user`, `nama_level_user`) VALUES (2, 'Administrasi');
INSERT INTO `t_level_user` (`id_level_user`, `nama_level_user`) VALUES (3, 'Manager Teknis');
INSERT INTO `t_level_user` (`id_level_user`, `nama_level_user`) VALUES (4, 'Supervisor');
INSERT INTO `t_level_user` (`id_level_user`, `nama_level_user`) VALUES (5, 'Analis');
INSERT INTO `t_level_user` (`id_level_user`, `nama_level_user`) VALUES (6, 'Klien');


#
# TABLE STRUCTURE FOR: t_permintaan_analisis
#

DROP TABLE IF EXISTS `t_permintaan_analisis`;

CREATE TABLE `t_permintaan_analisis` (
  `id_permintaan_analisis` int(11) NOT NULL AUTO_INCREMENT,
  `id_klien` text NOT NULL,
  `tanggal_deadline` date NOT NULL,
  `tanggal_permintaan` date NOT NULL,
  `nama_sample` text NOT NULL,
  `manager_teknis` text NOT NULL,
  PRIMARY KEY (`id_permintaan_analisis`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(60) NOT NULL,
  `level_user` text NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `user` (`id_user`, `username`, `password`, `level_user`) VALUES (1, 'admin', '$2y$05$9Y6S65jVrACTOeG8ad7PIeqNkm69rj6Zxj0TXPdrZWkrvqKCpWrdW', '1');
INSERT INTO `user` (`id_user`, `username`, `password`, `level_user`) VALUES (2, 'tes', '$2y$05$3Wq64evsbmCSw.09GxpoFuQmJIVOea4EyorN6pPd.RF7wYJUcspeC', '2');


